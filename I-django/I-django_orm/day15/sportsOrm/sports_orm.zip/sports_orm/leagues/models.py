from django.db import models
from django.db.models import Q
class League(models.Model):
	name = models.CharField(max_length=50)
	sport = models.CharField(max_length=15)
	created_at = models.DateTimeField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	def __str__(self):
		return self.name

class Team(models.Model):
	location = models.CharField(max_length=50)
	team_name = models.CharField(max_length=50)
	league = models.ForeignKey(League, related_name="teams", on_delete = models.CASCADE)

	def __str__(self):
		return self.team_name

class Player(models.Model):
	first_name = models.CharField(max_length=15)
	last_name = models.CharField(max_length=15)
	curr_team = models.ForeignKey(Team, related_name="curr_players", on_delete = models.CASCADE)
	all_teams = models.ManyToManyField(Team, related_name="all_players")

	def __str__(self):
		return f"{self.first_name} {self.last_name}"


def get_baseball_leagues():
    return League.objects.filter(sport__iexact="baseball")
def get_womens_leagues():
    return League.objects.filter(name__icontains="women")
def get_hockey_leagues():
    return League.objects.filter(sport__icontains="hockey")
def get_non_football_leagues():
    return League.objects.exclude(sport__iexact="football")
def get_conference_leagues():
    return League.objects.filter(name__icontains="conference")
def get_atlantic_leagues():
	return League.objects.filter(teams__location="Atlanta")
def get_teams_with_dallas():
	return Team.objects.filter(location__icontains="Dallas")
def get_teams_name_Raptors():
	return Team.objects.filter(team_name__icontains="Raptors")
def get_teams_contains_city():
	return Team.objects.filter(location__icontains="City")
def get_teams_start_with_T():
	return Team.objects.filter(team_name__startswith="T")
def order_teams_by_location():
	return Team.objects.all().order_by("location")
def order_teams_by_location_reverse():
	return Team.objects.all().order_by("-location")
def get_player_last_name_Cooper():
	return Player.objects.filter(last_name__iexact="Cooper")
def get_player_first_name_Joshua():
	return Player.objects.filter(first_name__iexact="Joshua")
def get_players_last_name_Cooper_except_first_name_Joshua():
	return Player.objects.filter(last_name__iexact="Cooper").exclude(first_name__iexact="Joshua")
def get_players_with_first_name_Alexander_or_Wyatt():
    return Player.objects.filter(Q(first_name__iexact="Alexander") | Q(first_name__iexact="Wyatt"))






