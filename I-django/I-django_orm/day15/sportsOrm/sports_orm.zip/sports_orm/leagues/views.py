from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker
from . import models 

def index(request):
	print(models.get_teams_contains_city())
	context = {
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
		"leagues": League.objects.all(),
		"baseball_leagues": models.get_baseball_leagues(),
		"womens_leagues": models.get_womens_leagues(),
		"hockey_leagues": models.get_hockey_leagues(),
		"non_football_leagues": models.get_non_football_leagues(),
		"conference_leagues": models.get_conference_leagues(),
		"atlantic_leagues": models.get_atlantic_leagues(),
		"teams_with_dallas": models.get_teams_with_dallas(),
		"teams_start_with_T": models.get_teams_start_with_T(),
		"teams_name_Raptors": models.get_teams_name_Raptors(),
		"teams_contains_city": models.get_teams_contains_city(),
		"player_first_name_Joshua": models.get_player_first_name_Joshua(),
		"player_last_name_Cooper": models.get_player_last_name_Cooper(),
		"players_last_name_Cooper_except_first_name_Joshua": models.get_players_last_name_Cooper_except_first_name_Joshua(),
		"order_teams_by_location": models.order_teams_by_location(),
		"order_teams_by_location_reverse": models.order_teams_by_location_reverse(),
		"players_with_first_name_Alexander_or_Wyatt": models.get_players_with_first_name_Alexander_or_Wyatt(),
	}
	return render(request, "leagues/index.html", context)


def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")